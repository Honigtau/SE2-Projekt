// Aufgabe 6.2
/*
 * Flexibler Parameter für die Methode informiereUeberAenderung(Aenderung aenderung)
 * der Klasse Beobachtbar des Beobachter-Entwurfsmusters.
 * Wird durchgereicht bei Ereignissen bis in die Klasse KassenWerkzeug
 * 
 * @author Gruppe 67
 * @version 11.06.2020
 */
package kino.fachwerte;

public enum Aenderung
{
    DATUMSAENDERUNG, VORSTELLUNGSAUSWAHL
}
