// Aufgabe 6.2
package kino.startup;

import java.util.HashSet;
import java.util.Set;

import kino.fachwerte.Aenderung;


/**
 * Die Klasse Beobachtbar im Rahmen des Beobachter-Entwurfsmusters.
 * 
 * @author Gruppe 67
 * 
 * @version 11.06.2020
 */

public abstract class Beobachtbar
{
    private Set<Beobachter> _beobachter;
    public Beobachtbar()
    {
        _beobachter = new HashSet<Beobachter>();
    }
    
    /**
     * Fügt einen Beobachter in die Menge aller Beobachter hinzu
     * 
     * @param beobachter
     * 
     * @require beobachter != null
     */
    
    public void fuegeBeobachterHinzu(Beobachter beobachter)
    {
        assert beobachter != null : "Vorbedingung verletzt: Beobachter existiert nicht!";
        
        _beobachter.add(beobachter);
    }
    
    /**
     * Informiert alle Beobachter über eine Ereignis
     * 
     * @param aenderung
     * 
     * @require (aenderung == "DATUMSAENDERUNG" || aenderung == "VORSTELLUNGSAUSWAHL")
     */
    
    protected void informiereUeberAenderung(Aenderung aenderung)
    {
        assert (aenderung == Aenderung.DATUMSAENDERUNG || aenderung == Aenderung.VORSTELLUNGSAUSWAHL):
            "Vorbedingung verletzt: keine gültige Aenderung!";
        
        for (Beobachter beobachter : _beobachter)
        {
            beobachter.reagiereAufAenderung(aenderung);
        }
    }
}
