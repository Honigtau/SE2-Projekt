// Aufgabe 6.2
package kino.startup;

import kino.fachwerte.Aenderung;

/**
 * Das Interface Beobachter im Rahmen des Beobachter-Entwurfsmusters.
 * 
 * @author Gruppe 67
 * 
 * @version 11.06.2020
 */

public interface Beobachter
{
    void reagiereAufAenderung(Aenderung aenderung);
}
