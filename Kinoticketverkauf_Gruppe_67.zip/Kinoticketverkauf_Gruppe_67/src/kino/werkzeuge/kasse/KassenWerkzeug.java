package kino.werkzeuge.kasse;

import java.awt.event.ActionEvent;

import java.awt.event.ActionListener;

import kino.fachwerte.Aenderung;
import kino.fachwerte.Datum;
import kino.materialien.Kino;
import kino.materialien.Tagesplan;
import kino.materialien.Vorstellung;
import kino.startup.Beobachter;
import kino.werkzeuge.datumsauswaehler.DatumAuswaehlWerkzeug;
import kino.werkzeuge.platzverkauf.PlatzVerkaufsWerkzeug;
import kino.werkzeuge.vorstellungsauswaehler.VorstellungsAuswaehlWerkzeug;


/**
 * Das Kassenwerkzeug. Mit diesem Werkzeug kann die Benutzerin oder der Benutzer
 * eine Vorstellung auswählen und Karten für diese Vorstellung verkaufen und
 * stornieren.
 * 
 * @author SE2-Team, Gruppe 67
 * @version SoSe 2020, Änderung 11.06.2020
 */
public class KassenWerkzeug implements Beobachter // Aufgabe 6.2 Beobachtermuster
{
    // Das Material dieses Werkzeugs
    private Kino _kino;

    // UI dieses Werkzeugs
    private KassenWerkzeugUI _ui;

    // Die Subwerkzeuge
    private PlatzVerkaufsWerkzeug _platzVerkaufsWerkzeug;
    private DatumAuswaehlWerkzeug _datumAuswaehlWerkzeug;
    private VorstellungsAuswaehlWerkzeug _vorstellungAuswaehlWerkzeug;

    /**
     * Initialisiert das Kassenwerkzeug.
     * 
     * @param kino das Kino, mit dem das Werkzeug arbeitet.
     * 
     * @require kino != null
     */
    public KassenWerkzeug(Kino kino)
    {
        assert kino != null : "Vorbedingung verletzt: kino != null";

        _kino = kino;

        // Subwerkzeuge erstellen
        _platzVerkaufsWerkzeug = new PlatzVerkaufsWerkzeug();
        _datumAuswaehlWerkzeug = new DatumAuswaehlWerkzeug();
        _vorstellungAuswaehlWerkzeug = new VorstellungsAuswaehlWerkzeug();
        
        // Aufgabe 6.2
        _datumAuswaehlWerkzeug.fuegeBeobachterHinzu(this);
        _vorstellungAuswaehlWerkzeug.fuegeBeobachterHinzu(this);

        // UI erstellen (mit eingebetteten UIs der direkten Subwerkzeuge)
        _ui = new KassenWerkzeugUI(_platzVerkaufsWerkzeug.getUIPanel(),
                _datumAuswaehlWerkzeug.getUIPanel(),
                _vorstellungAuswaehlWerkzeug.getUIPanel());

        registriereUIAktionen();
        setzeTagesplanFuerAusgewaehltesDatum();
        setzeAusgewaehlteVorstellung();

        _ui.zeigeFenster();
    }

    /**
     * Fügt die Funktionalitat zum Beenden-Button hinzu.
     */
    private void registriereUIAktionen()
    {
        _ui.getBeendenButton().addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                reagiereAufBeendenButton();
            }
        });
    }

    /**
     * Setzt den in diesem Werkzeug angezeigten Tagesplan basierend auf dem
     * derzeit im DatumsAuswahlWerkzeug ausgewählten Datum.
     */
    private void setzeTagesplanFuerAusgewaehltesDatum()
    {
        Tagesplan tagesplan = _kino.getTagesplan(getAusgewaehltesDatum());
        _vorstellungAuswaehlWerkzeug.setTagesplan(tagesplan);
    }

    /**
     * Passt die Anzeige an, wenn eine andere Vorstellung gewählt wurde.
     */
    private void setzeAusgewaehlteVorstellung()
    {
        _platzVerkaufsWerkzeug.setVorstellung(getAusgewaehlteVorstellung());
    }

    /**
     * Beendet die Anwendung.
     */
    private void reagiereAufBeendenButton()
    {
        _ui.schliesseFenster();
    }

    /**
     * Gibt das derzeit gewählte Datum zurück.
     */
    private Datum getAusgewaehltesDatum()
    {
        return _datumAuswaehlWerkzeug.getSelektiertesDatum();
    }

    /**
     * Gibt die derzeit ausgewaehlte Vorstellung zurück. Wenn keine Vorstellung
     * ausgewählt ist, wird <code>null</code> zurückgegeben.
     */
    private Vorstellung getAusgewaehlteVorstellung()
    {
        return _vorstellungAuswaehlWerkzeug.getAusgewaehlteVorstellung();
    }
    
    // Aufgabe 6.2
    
    /**
     * Reaktione des Kontextwerkzeuges auf eine Änderung in einem der beobachteten
     * Subwerkzeuge im Rahmen der Beobachter-Entwurfsmusters.
     * Wurde interaktiv das Datum geändert wird die Vorstellungsauswahl aktualiert.
     * Eine interaktive Vostellungsauswahl passt die Anzeige des Platzauswahl an.
     * 
     * @param aenderung
     * 
     * @require (aenderung == "DATUMSAENDERUNG" || aenderung == "VORSTELLUNGSAUSWAHL")
     */

    @Override
    public void reagiereAufAenderung(Aenderung aenderung)
    {
        assert (aenderung == Aenderung.DATUMSAENDERUNG || aenderung == Aenderung.VORSTELLUNGSAUSWAHL):
            "Vorbedingung verletzt: keine gültige Aenderung!";
        
        switch (aenderung)
        {
            case DATUMSAENDERUNG :
                setzeTagesplanFuerAusgewaehltesDatum();
                break;
                
            case VORSTELLUNGSAUSWAHL :
                setzeAusgewaehlteVorstellung();
                break;
        }
    }
}
